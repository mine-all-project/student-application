package org.example.textreader.common;

/**
 * TODO 字典信息
 */
public class DIC {
    public static final int READ_INFO_WAIT = 1;
    public static final int READ_INFO_SUCCESS = 0;
    public static final int READ_INFO_FAIL = 2;


    public final static int PAGE_SIZE = 10;
    public final static String BASE_SUCCESS_MESSAGE = "操作成功";

}
