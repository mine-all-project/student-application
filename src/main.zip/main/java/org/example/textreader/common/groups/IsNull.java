package org.example.textreader.common.groups;

public interface IsNull {
}
