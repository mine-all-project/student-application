package org.example.textreader.common.groups;

public interface IsNotNull {
}
