package org.example.application.common.groups;

/**
 * 用于属性校验的校验组-修改
 */
public interface IsEdit {
}
