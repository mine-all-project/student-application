package org.example.application.common.groups;

/**
 * 用于属性校验的校验组-检验数据长度
 */
public interface IsCheckLength {
}
